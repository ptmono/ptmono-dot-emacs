void foo() {
    if (  abc
       && f(x,
	    y,
	    z) == 17
       || ( bits0
	  & bits1
	  )
       ) x = 17;
}

/* Local Variables: */
/* c-file-offsets: ((arglist-cont . (c-lineup-arglist-operators 0)) (arglist-cont-nonempty . (c-lineup-arglist-operators c-lineup-arglist)) (arglist-close . c-lineup-arglist-close-under-paren)) */
/* End: */
