template<class A,
	 class
	 B>
class C
{
}
