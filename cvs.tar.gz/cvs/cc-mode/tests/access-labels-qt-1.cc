class MyWidget
{
public:
    void aFunction();
public
#define foo "FOO" 
slots
#define bar "BAR"
:
    void doSomething();
protected /* comment */ slots:
    void doSomethingElse();
private slots:
    void doSomethingPrivate ();
signals:
    void changed();
more slots:
    int foo;
};
