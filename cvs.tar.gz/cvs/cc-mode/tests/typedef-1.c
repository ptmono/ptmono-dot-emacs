int dummy;

typedef struct
{
    float real;
    float imag;
} COMPLEX;

typedef enum
{
    RED, GREEN, BLUE
} COLORS;

typedef unsigned int *foo;
typedef xyz xyz_array_t[1];
