struct shmid_internal
shmconv(
    register int	s)
{
    int foo = 1;
};

struct shmid_internal 
{
    int i = 1;
};
