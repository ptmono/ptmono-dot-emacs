class A
{
    class B
    {
    };
};

// Local Variables:
// c-file-offsets: ((class-open . c-indent-one-line-block))
// End:
