int main()
{
    *this <<
        "zzz";
    (*this) <<
        "zzz";
}
