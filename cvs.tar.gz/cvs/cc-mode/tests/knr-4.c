
#define decl(X,Y,Z)				\
    int X(Y, p)					\
	int Y;					\
	char *p;				\
    {Z}
