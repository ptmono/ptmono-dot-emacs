void main() {
    if (1<0) return;
}
int b[] = {
    0,
};
