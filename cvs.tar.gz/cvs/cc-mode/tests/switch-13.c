int foo(void)
{
    switch (i) {
    case 1: /* : */
	{
	}
	break;
    }
}
/*
 * Local Variables:
 * c-file-offsets: ((statement-case-open . +))
 * End:
 */
