A[] three =
{
    new A()
};
