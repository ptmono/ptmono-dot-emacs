/*
  \*/
/**/
int x;

/* Most emacsen have problems with a backslash before the comment
 * ender.  This test case documents that.
 *
 * Local Variables:
 * cc-test-skip: (emacs-19 emacs-20 emacs-21 emacs-22 emacs-23 xemacs-19 xemacs-20)
 * End:
 */

