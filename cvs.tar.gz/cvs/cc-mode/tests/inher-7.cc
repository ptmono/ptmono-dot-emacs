Class::Class(Other *cl) : BaseClass(cl->method(), true),
			  var(10)
{}
