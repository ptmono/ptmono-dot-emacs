class X
{
    SortableArray<A *, String> i_a;
    class Y2 : public T<x>
    {
    public:
	Y2()
        {
            y = z;
        }
    };
};
