SIGTYPE
fatal_error_signal (sig)
    int sig;
{}
