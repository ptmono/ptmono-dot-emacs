int main()
{
    if ((a < b) || (c > d)) {}
}
