int main()
{
    int x;

    switch (x) {
    case 1:
    {
        x;
    } 
    break;
    case 2:
        x = 3;
        break;
    }
}
