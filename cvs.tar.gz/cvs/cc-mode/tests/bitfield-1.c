struct foo {
    int a:1,
	b:3,
	c:5;
};
