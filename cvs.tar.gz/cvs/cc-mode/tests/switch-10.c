void foo(int a) {
    switch (a) {
    case 1:    // Example: "1:2:3"
    {}
    break;
    }
}
