int main()
{
    if (func(arg1,
	     arg2)) {
      error:
	dothis();
    }
}
