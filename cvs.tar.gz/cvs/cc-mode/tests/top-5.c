int
bar =
    gnu;
