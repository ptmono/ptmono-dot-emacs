MyClass::MyClass (my_args)
    : FQN::of::base::Class(their_args),
      my_member_1(value),
      my_member_2(value)
{}
