enum foo {AA, BB,
	  CC};
enum ruta {
    N1 = (op = 1),
    P2 = 4,
    T3
} ruta_1;
