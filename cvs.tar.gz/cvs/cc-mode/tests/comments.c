int main()
{
    /*
     *
     */

    /*
    **
    **
    */

    /**
     **
     **
     **/

    /***
     ***
     ***
     ***
     ***/

    /**
    ***
    ***
    **/

    /* This is a test
       It does work */

    /* This is also a test
       Does it work?
    */

    /* This is also a test
       The second line works, but
       Does the third? */

    /* What about this one, which

       has a blank line?
    */
}
