public class Test {
    public  int val =
	3;

    public void test() {
	public int val2 =
	    3;
    }
    public void run()
	throws ThreadDeath {
	// a comment
    }

    public void run2() throws ThreadDeath {
	// a comment
    }
}
