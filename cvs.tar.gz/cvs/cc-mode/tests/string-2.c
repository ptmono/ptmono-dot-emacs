char *s = "x y z"
    ;
char *s = "x y z";
char *s = "x y z
a";
char *s = "x y z\
a";
