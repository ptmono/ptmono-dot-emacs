main (int argc, _char *argv[]);	/* Not handled correctly. */
main (int argc, _char *argv[])
{}
