int main()
{
    /*
     *
     */

    /*
    **
    **
    */

    /**
     * A javadoc comment
     *
     */

    /* This is a test
       It does work */

    /* This is also a test
       Does it work?
    */

    /* This is also a test
       The second line works, but
       Does the third? */
}
