class Frog
{
private:

    int a 
    (                   // this paren should line up with 'int a'
        int arg1,
        int arg2
        );

    int b (
        int arg1,
        int arg2
        )

        };
