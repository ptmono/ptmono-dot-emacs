abstract class Parameter {
    final static byte[] nullconstant(byte flags,
				     int operand) {
	byte parameter[] = new byte[4];
    }
}
