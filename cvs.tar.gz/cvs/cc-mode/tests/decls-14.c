#define foo(bar) do {int i = 0;} while (0)
struct str *gazonk();
