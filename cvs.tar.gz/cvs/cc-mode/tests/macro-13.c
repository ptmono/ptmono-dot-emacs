void f() {
    FOO
	if (x) y;
#define X x; y
    z;
}
