public class dumb
{
    /**
     * Javadoc style comment 
     * foop {@link url1} gnu {@link url2}
     * invalid: { {@link
     * <code>some code</code>
     * <a
     * href="<x>">x</a>
     * <a href="<x>>a<b c < d>
     * a&lt;b c &lt; d&gt;
     * a&b c; & d;
     *
     * @param foo  A foo param. @ foo@bar
     * @return Nothing.
     * @see Bar
     */

    /** @return nil
     */

    // Another java comment

    /*
     * traditional C block
     * comment
     */
}
