class whatever
{
public:
    int i,
        j;
};

class whatever
{
public:
    whatever();
    int i,
        j;
};


class whatever
{
    // note that <this> is in lt/gt symbols, and affects continuation
    // indenting:
    int i,
        j;
};
