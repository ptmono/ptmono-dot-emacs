foo:
if (a)
    b;
bar: x(y);
