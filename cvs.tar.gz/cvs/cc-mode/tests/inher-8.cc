class My_CORBA_Class
    : public POA_Orphans::AMH_Orphanage
    , public virtual PortableServer::RefCountServantBase
{};
