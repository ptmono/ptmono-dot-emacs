<?php
include 'header.php';
if (dff) {
  thank();
  // Bad indentation on next line?
     }
for (;;) {
  you();
}
?>
