main()
{
    int a;

    switch (a) {
    case 1:
        a=1;
        b=2;
        break;
    case '2':
        a=1;
        a=2;
        break;
    case AAAA::BBBB :
        func() ;
        break ;

    case AAAA::CCCC :
        func() ;
        break ;

    case AAAA::DDDD:
        func() ;
        break ;
    }
}
