int main() 
{
    switch( c ) {
    case 1:
        foo();
        baz();
        break;
    case 2:
        bar();
        switch( d ) {
        case 0:
            faz();
            bilz();
            break;
        case 1:
            zap();
            if ( e )
                break;
            zom();
            break;
        }
        zop();
        break;
    case 3:
        bim();
        switch( f ) {
        case 0:
            zim();
            bilz();
            break;
        case 1:
            zap();
            if( e )
                break;
            til();
            break;
        }
        break;
    }
}
