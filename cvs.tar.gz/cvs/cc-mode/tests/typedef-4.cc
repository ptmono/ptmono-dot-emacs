typedef SCM (*guile_callback)();
