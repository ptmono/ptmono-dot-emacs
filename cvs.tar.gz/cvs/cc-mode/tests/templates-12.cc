void f() {
    c b;
    extern int foo (a < b, c > d);
    extern int foo (xx, a < b, c > d);
    extern int foo (a < b, c > d, yy);
    extern int foo (xx, a < b, c > d, yy);
    foo (a < b, c > d);
    foo (xx, a < b, c > d);
    foo (a < b, c > d, yy);
    foo (xx, a < b, c > d, yy);
}
