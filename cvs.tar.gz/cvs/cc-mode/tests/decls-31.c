int main()
{
  while (foo()[(int) (**((unsigned char **)s))])
    ;
}
