#if defined(PURIFY) || defined(__CHECKER__) ||				\
    defined(DEBUG_MALLOC) || defined(USE_VALGRIND)
defined(INVALID)
#endif
