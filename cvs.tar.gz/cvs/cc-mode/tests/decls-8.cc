class Foo {
} a,
    b;
class {
}
    a,
    b;
int main() {
    if (x) {
    } a, b;
    if (x) {
    } int a;
}
