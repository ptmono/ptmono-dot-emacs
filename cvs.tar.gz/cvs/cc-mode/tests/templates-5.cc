ACE_Map_Manager <int,
		 FrameworkManagement::GroupCallback *,
		 ACE_Mutex> FrameworkManager_i::groupCallbacks;

ACE_Map_Manager <int,
		 FrameworkManagement::ProjectCallback *,
		 ACE_Mutex> FrameworkManager_i::projectCallbacks;
