class reverse_iterator
{
  reverse_iterator() {}
  explicit reverse_iterator(iterator_type x) {}
};
