void foobar(/* input */ int a,
            /* input */ int b,
            /* input */ int c)
