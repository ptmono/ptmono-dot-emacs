char prot[100], descr[110];
