class Foo {
public:
    class Forward;                           // A forward declaration.
    ::Bar *function();                       // Type Bar at global scope.
};
