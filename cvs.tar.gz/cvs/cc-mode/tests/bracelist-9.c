int foo =
{
    /* first  */ 1,
    /* second */ 2,
};
int bar = { /* first  */ 1,
	    /* second */ 2,
};
