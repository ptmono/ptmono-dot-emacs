struct foo bar,
    bar,
    baz;
