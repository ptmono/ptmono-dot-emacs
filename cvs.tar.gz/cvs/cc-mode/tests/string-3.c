char *a = "foo", *b = "bar
