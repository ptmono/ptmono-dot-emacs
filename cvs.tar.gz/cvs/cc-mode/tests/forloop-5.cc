void f() {
    for (int a = -1, b = 1;;) {}
}
