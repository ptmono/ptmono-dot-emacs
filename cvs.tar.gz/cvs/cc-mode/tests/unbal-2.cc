void a()
{}
class x
{
void b()
{}
void c()
{}
}
void d()
{}
