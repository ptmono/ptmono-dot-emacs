int foo() {
    while (b) if (y)
		  while (t)
		      p;
    while (b) foo: if (y)
		  while (t)
		      p;
    while (b)
      foo: if (y)
	    while (t)
		p;
    while (b)
      foo: if (x) y; else
	    while (t)
		p;
    while (b)
      foo: if (x) y; if (x)
			 while (t)
			     p;
}
