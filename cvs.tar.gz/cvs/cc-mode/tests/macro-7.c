#define FOO(x)					\
    x = 1;					\

int bar;
