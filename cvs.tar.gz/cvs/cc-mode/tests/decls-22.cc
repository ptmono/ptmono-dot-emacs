Bar wales() const {return NULL;}
