namespace A {
    class X;
}
class B {
    int i;
};
extern "C" {
    int i;
}
void f() {
					int i;
}

// Local Variables:
// c-special-indent-hook: (c-gnu-impose-minimum)
// c-label-minimum-indentation: 40
// End:
