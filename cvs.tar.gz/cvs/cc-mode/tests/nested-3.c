int main()
{
    char *example()
    {
	f();
    }
    return 0;
}
