int main()
{
    if (x)
      foo:
	for (;;) {
	}
    else x;
}
