int main()
{
    bar();
  label:
    plop();
}


int main()
{
  label:
    plot();
    flop();
}

int main()
{
  label:
    plot();
  babel:
    flop();
}

int main()
{
  label:
    /* foo */
    plot();
  babel:
    /* foo */
    flop();
}
