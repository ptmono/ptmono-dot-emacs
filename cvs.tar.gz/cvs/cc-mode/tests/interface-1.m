@interface foobar
{
@public
    id bar;
}
