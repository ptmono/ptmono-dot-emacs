int A::A(dsad) 
    : B<int>(),
      C()
{}
