main(int argc, char *argv[])
{
    int i, j;
    switch (argc)
        {
	stop:
            int k;

        case 0:
            i = 6;
            j = 5;
            break;
        case 0:
            i = 6;
            j = 5;
            break;
        case 0:
            i = 6;
            j = 5;
            break;
        }
}
