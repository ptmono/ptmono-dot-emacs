void foo() {
  for (int n = 0; n < pml->GetMoveCount(); n++) {}
}
