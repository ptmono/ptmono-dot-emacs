// This should not be recognized as a bracelist!
void Class::operator=() 
{
    if (1)
        {
        }
}
