#define WITH_NODES_BLOCK(TYPE, OTHERTYPE, IND, INDVAL)			\
    struct OTHERTYPE *onode;						\
    struct TYPE *nnode;
