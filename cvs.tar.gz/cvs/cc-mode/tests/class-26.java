class Foo {
    {
	initialize();
    }
    static {
	static_initialize();
    }
    static
    {
	static_initialize();
    }
}
