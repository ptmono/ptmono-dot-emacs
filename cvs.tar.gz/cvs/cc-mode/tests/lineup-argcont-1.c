int main (void) {
    if (foo () {}
	else
/* Local Variables: */
/* c-file-offsets: ((arglist-cont-nonempty . c-lineup-argcont)) */
/* End: */
