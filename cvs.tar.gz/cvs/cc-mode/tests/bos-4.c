int main()
{
    switch (c) {
    case NUMBER:
        * (unsigned*)(fn + font_name_prop_table[i].offset) =
            font_prop;
        break;
    }
}
