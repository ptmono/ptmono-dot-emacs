int f()
{
    if (a) {
    } else if (b)
	x;
    if (a) {
    } else
	x;
}
