ABCDEFGHIJKLMNOPQRSTUVWXYZ ({
	a;
    },
    {
	b;
    }
    );

ABCDEFGHIJKLM (NOPQRSTUVWXYZ ({
	    a;
	},
	{
	    b;
	}
	)
    );

int main() {
    deklarationsblankett (  offeranod (1,
	    2
	    ),
	3
	);
    deklarationsblankett + (  offeranod, (1,
	    2
	    ),
	3
	);
    if ( ({
		y = foo ();
	    }
	    )
	)
	a1 = 17;
}

/* Local Variables: */
/* c-file-offsets: ((arglist-cont-nonempty . +)) */
/* End: */
