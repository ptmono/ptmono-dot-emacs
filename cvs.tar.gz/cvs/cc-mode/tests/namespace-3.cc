namespace
{
    int i;
}
