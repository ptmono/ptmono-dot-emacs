inline void foo(A *, B &, C) {d;}
