struct blah
{
    int i[3];
};


static struct blah wibble = 
{
    1,
    2,
    3
};


int a[3] =
{
    1,
    2,
    3
};
