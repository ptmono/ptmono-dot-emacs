namespace foo {

    void xxx() {
    }
    
}


namespace bar
{

    void xxx()
    {
    }
    
}
