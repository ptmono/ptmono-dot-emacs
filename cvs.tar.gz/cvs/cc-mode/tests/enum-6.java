public enum Foo {
    A,
    B,
    C,
    D;
}
