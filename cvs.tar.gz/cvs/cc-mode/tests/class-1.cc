class Foo
{
public:
    Foo()
    {
        thing();
    };
    int foo( void );
    int bar( void )
    {
        thing();
    };

private:
    int i;
    int j;
};
