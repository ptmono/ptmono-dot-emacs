extern int no_such_function (void *arg1, int *arg2)
    throw();
int a;
extern int no_such_function (void *arg1, int *arg2)
    __THROW;
int a;
extern int wcscmp (__const wchar_t *__s1, __const wchar_t *__s2)
    __THROW __attribute_pure__;
int a;
