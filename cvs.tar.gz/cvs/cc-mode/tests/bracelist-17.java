public class Foo {
    static public void main() {
	setArray(
		 new String[] {
		     "a",
		     new String("b"),
		 });
    }
}
