long
SABSRX_AA_CreateFundingArrangement(
    struct rx_call      *rxcall,
    elem_list           *elist,
    long                *oracle_code)
{
    // ...
}

void 
XcvrWrite (struct ioparms *t)
{
    if( TRUE )
        return;
}
