void f() {
    t1 a;
    t2[] a;
    t3 a[];

    t4 a = 1;
    t5[] [ ] a = {{}};
    t6 a [ ][] = {{}};

    v1 ();
    v2 (id);
    v3 [id];
    v4 (id) (id);
}
