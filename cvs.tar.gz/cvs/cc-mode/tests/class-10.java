class foo
{
    void bar()
	throws package.PACKAGE.Package.PackAge.ReallyLongExceptionName
    {
	int field_name;
    }
}
