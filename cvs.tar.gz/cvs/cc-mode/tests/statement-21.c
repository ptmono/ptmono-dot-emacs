void foo()
{
    if (1) {
    } else if (1) {
    } else if (1) {
    } else if (1) {
    } else {
    }
    if (1) {
    } else if (1) {
    } else
	if (1) {
	} else if (1) {
	}
}
