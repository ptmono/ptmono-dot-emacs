int a() {
foo: {
	x;
    }
}
int b() {
    float f;
foo: {
	x;
    }
}
