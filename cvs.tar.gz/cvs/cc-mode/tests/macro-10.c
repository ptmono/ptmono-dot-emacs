BARGONKA (if (a)
	x,
    if (a)
	x
    );

/* Local Variables: */
/* c-file-offsets: ((arglist-cont-nonempty . +)) */
/* End: */
