void f() {
    switch (x) {
    case foo: case -1: case 17 :
    case 1 - 3: case BAR :
    }
}
