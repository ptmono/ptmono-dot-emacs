void func()
{
    other(find_if(begin, end, pred),
          hoho);
}
