template<class T>
int A<T>::foo( void )
{
    statement;
    statement;
}


template <class T>
class Foo : T
{
public:
    Foo( void );
    ~Foo( void );
};


template< class T >
int A<T>::foo( void )
{
    statement;
    statement;
}
