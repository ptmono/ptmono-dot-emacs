void
EmitClassThunk(void)
{
    int i;
    
    for( i = 0; i < classIndex; ++i )
        switch( Declaration_KEY( classList[i] ) )
            {
            case KEYroutine_decl:
            case KEYclass_decl:
            }
}
