// Sample:
class test {
    int test () {
	int x = testing (
			 1, 2, 3
			 );
    }
}
