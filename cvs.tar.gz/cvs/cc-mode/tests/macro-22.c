void f() {
  foo
#define X ;
      :
    bar;
}
