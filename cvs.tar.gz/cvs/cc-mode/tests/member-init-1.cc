Foo()
    : bar_( 0 ) {
    f();
}

namespace Xyzzy {
    class FooBar {
    public:
        FooBar() :
            _member1,
            _member2
        { }
    };
}
