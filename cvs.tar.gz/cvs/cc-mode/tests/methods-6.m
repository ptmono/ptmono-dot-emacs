// Test.

- (void) thefirstlongnamename: (int *) first
		  thefirstarg: (int *) second;
- (void) thesecondname: (int *) first
	  thesecondarg: (int *) second;

@interface foo :
    bar
{
}
- (void) nickelandhum;
@end
