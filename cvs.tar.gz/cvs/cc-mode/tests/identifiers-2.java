// Foo.
Bar.Gnu x;
