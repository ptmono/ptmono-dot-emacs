public class Foo {
    public String arr2[][] =
    {
	{"d1", "d2",},
	{"d1",
	 "d2"
	}
	,
	{
	    "d1",
	    "d2",
	},
    };
    public String arr1[][] = new String[][]
	{
	    {"d1", "d2",},
	    {"d1",
	     "d2"
	    }
	};
    public String fun()
    {
	a = new b[2];
	{
	    "d1",
		"d2";
	}
	a = new b[2]
	    {
		"d1",
		"d2"
	    };
    };
}
