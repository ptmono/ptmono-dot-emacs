X<Y<class A<int>::B, BIT_MAX >> b>, ::operator<> :: Z<(a>b)> :: operator
const X<&foo>::T Q::G<unsigned short int>::*volatile const ();
