QWLaserBase<_EQWLaser, P, _Grating>::
QWLaserBase(Contact* contact) {}
