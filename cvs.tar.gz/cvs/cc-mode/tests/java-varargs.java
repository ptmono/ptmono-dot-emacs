public class javaVarargs {

    private void varargsTest( int Foo, System.Writer foo, System.ArrayList... list) {
        int pi;
        ArrayList l;
    }

}
