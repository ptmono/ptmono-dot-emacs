class Queue
{
private:
    int nextArrive,
        nextFinish;
    int time,
        len;    
};
