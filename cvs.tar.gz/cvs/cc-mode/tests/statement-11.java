class Baz
{
    int blah()
    {
	return 1
	    + 2
	    + 3
	    + foobar()
	    + 5
	    + 6;
    }
}
