t1 *fn (t2 *b);			/* How could this be done better? */
t3 *fn (t4 *b) {}
struct t5 *fn (t6 *b);
struct t7 *fn (t8 *b) {}
int fn (t9 *a, t10 *b);
int fn (t9 *a, t10 *b) {}
