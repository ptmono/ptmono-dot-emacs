class Foo
{
public:
    Foo() {}
    ~Foo() {}
};
class Bar
{
public:
    Bar();
    ~Bar();
};
