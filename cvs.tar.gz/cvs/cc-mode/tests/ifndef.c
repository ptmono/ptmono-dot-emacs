#ifndef foo
bar
#endif
