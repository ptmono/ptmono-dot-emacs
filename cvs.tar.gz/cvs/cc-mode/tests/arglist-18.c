long_function_name (a,
		    b
    );
long_function_name (
    a,
    b
    );
long_function_name ({
	a;
    },
    b
    );
long_function_name (
    {
	a;
    },
    b
    );
long_function_name (a,
		    {
			b;
		    }
    );
long_function_name (
    a,
    {
	b;
    }
    );
long_function_name ({
	a;
    },
    {
	b;
    }
    );
long_function_name (
    {
	a;
    },
    {
	b;
    }
    );
long_function_name (x, {
	a;
    },
    b);
long_function_name (x, y {
	a;
    },
    b);
