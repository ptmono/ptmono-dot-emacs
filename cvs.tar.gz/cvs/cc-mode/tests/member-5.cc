class A {
    A() : i(f(5,
	      8)),
	  j(7) {}
}
