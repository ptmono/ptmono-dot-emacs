int main()
{
    switch (x) {
    case 1:
    {
    }
    default:
    {
    }
    break;
    }
}
