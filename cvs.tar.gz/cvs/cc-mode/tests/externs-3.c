extern "C" foo_t my_foo;
extern foo_t my_foo;
