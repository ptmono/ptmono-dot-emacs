int *operator[](int i)
{
    Require(i > 0 && i < height);
}
