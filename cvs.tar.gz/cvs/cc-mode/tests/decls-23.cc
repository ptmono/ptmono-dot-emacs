struct x {
    typedef Foo Bar;
};
void x() {
    jah (a, Bar (b));
}
