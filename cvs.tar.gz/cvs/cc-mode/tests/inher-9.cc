A::A()
/* This colon caused the indent of the second and following attrs : */
    : my1(),
      my2(),
      my3(),
{
}
