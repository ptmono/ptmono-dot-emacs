int main (int argc, char *argv[])
{
    switch (exp)
        {
        default:
            break;		/* wrong indentation!! */
        }
}
