#!/usr/bin/python
# -*- coding:utf-8 -*-

import urllib2

emacs_wiki_files = [\
    "anything.el",
    "anything-ipython.el",
    "anything-show-completion.el",
    "buff-menu+.el",
    "extview.el",
    "highlight-current-line.el",
    "highline.el",
    "htmlize.el",
    "info+.el",
    "shell-command.el",
    "tabbar.el",
    "vbnet-mode.el",
    "visual-basic-mode.el"
    ]

### third party 
# "boxquote.el",
# "chronometer.el",
# "cmake-mode.el",
# "connection.el",
# "delicious-el",
# "dictionary.el",
# "dictionary-init.el",
# "ell.el",
# "freemind.el",
# "iimage.el",
# "isearch-ouline.el",
# "javascript.el",
# "js-comint.el",
# "link.el",
# "lua-mode.el",
# "memory-usage.el",
# "moz.el",
# "multi-mode.el",
# "outline-magic.el",
# "php-mode.el",
# "reportmail.el",
# "schedule.el",
# "tetris.el",

### package
# bibl-mode
# cclookup
# delicious-el
# g-client
# js2-mode-read-only
# mldonkey-el-0.0.4b
# pymacs
# python-mode
# rfcview


class EmacsWikiEl:
    """http://www.emacswiki.org/emacs/download/anything.el
    """
    
    base_url = "http://www.emacswiki.org/emacs/"

    def __init__(self, url=None, filename=None):
        self.content = None
        self.url = url
        self.filename = filename
        if self.filename:
            self._url_from_filename(filename)


    def _url_from_filename(self, filename):
        self.url = EmacsWikiEl.base_url + filename


    def check(self):
        if self.content:
            return True
        else:
            return False


    def downloadFile(self, filename):
        "If no file in emacsWiki, then return None. Other returns contents."
        self._url_from_filename(filename)
        return self.download()


    def download(self):
        self.download_url(self.url)
        return self.content
        
        
    def download_url(self, url):
        try:
            self.content = urllib2.urlopen(url).read()
        except urllib2.HTTPError:
            # There is no page
            self.content = None
            return
        
        if len(self.content) == 0:
            self.content = None


    def url_from_filename(self, filename):
        self.url = EmacsWikiEl.base_url + filename


def download(filename):
    """
    >>> download("akknn.el")
    http://www.emacswiki.org/emacs/akknn.el is not exits.
    """
    ewe = EmacsWikiEl()
    contents = ewe.downloadFile(filename)
    if contents:
        return contents
    else:
        print "%s is not exits." % ewe.url

def check_emacswiki_files():
    for a in emacs_wiki_files:
        import time
        time.sleep(2)
        download(a)


def test():
    import doctest
    doctest.testmod()

