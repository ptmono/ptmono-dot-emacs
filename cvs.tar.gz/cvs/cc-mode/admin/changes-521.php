<!-- -*- html -*- -->
<?php
  $title = "Changes for CC Mode 5.21";
  $menufiles = array ("links.h", "changelinks.h");
  include ("header.h");
?>

<p>Version 5.21 is primarily a bug fix release.  See also the list of
<a href="changes-520.php">user visible changes for version 5.20</a>.

<?php include ("footer.h"); ?>
