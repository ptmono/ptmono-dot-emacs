int main()
{
    if (
        ((a==b) && (c==d)) ||
        ((e==f) && (g==h))
        )
        i = j;
    k = l;
};
