int foo(int i)
{
    switch (i)
        {
        case attributeDiscriminatorConstruct:
        {
            // This line is inclass acc. to C-c C-s.
            break;
        }
        }
}
