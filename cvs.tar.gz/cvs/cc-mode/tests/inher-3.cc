class A
    :
    public B
