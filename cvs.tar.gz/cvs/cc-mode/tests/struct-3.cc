struct frob 
{
    int x : 5,
        y : 3;
}
