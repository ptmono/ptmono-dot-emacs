class foo
{};
class bar // class namespace struct extern ;()=<>"#|
{};
int gnu()
// extern
{}
