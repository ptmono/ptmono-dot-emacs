void foo()
{
    ;
    /* press TAB here */
    foo;
    ;
    bar;
    ;
    blank;
  label:
    ;
    blank;
}
