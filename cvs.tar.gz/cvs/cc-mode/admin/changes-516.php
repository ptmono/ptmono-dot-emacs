<!-- -*- html -*- -->
<?php
  $title = "Changes for CC Mode 5.16";
  $menufiles = array ("links.h", "changelinks.h");
  include ("header.h");
?>

<p>This is primarily a bug fix release.  Users of XEmacs 19.15 and
Emacs 19.34 are highly encouraged to pick up this release.

<p>See also the list of <a href="changes-515.php">user visible
changes for version 5.15</a>.

<?php include ("footer.h"); ?>
