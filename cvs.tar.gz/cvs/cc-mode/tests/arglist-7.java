public class spam
{
    public buggy()
    {
	spew(
	     -1, -1 );
    }
}
