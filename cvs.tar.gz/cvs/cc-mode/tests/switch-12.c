int main()
{
    switch (x) {
    default:
	foo();
    a_label: bar();
    case 17: vvox();
    }
}
