int x ()
{
    if (a)
	{}
    else if (b)
	;
    if (a)
	{}
    else
	if (b)
	    ;
}
