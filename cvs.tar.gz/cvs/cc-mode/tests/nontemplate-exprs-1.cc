int main()
{
    if (a<0 || b>99) {}
    if (c<0 && d>99) {}
}
