public class foreach {

    public static void main( String [] args ) {
        for (T o: a) {
            c.add(o);
        }

        for ( java.util.ArrayList list : list ) {
	    
        }
    }
    
}
