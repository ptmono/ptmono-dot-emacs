#include /**/ <string.h>
#define /**/ FOO 17
#define /**/ BAR(X,Y)
