class foo : 
    public a,
    public b
{
public:
    foo(int i);
    bar();
    ~foo();
}
