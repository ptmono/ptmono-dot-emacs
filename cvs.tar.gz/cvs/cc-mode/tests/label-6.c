int main(void) {
    int x;
    x = testcase() ? 1 : 0;	/* Not a case label. */
    return 0;
}
