namespace n
{
    int a = func<int,
                 float>();
}

void f()
{
    int a = func<int,
                 float>();
    
    int b = func<
        int,
        float>();
}
