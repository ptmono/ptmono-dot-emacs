class spam
{
private:
    int x;
public :
    int y;
protected	:
    int z;
}
