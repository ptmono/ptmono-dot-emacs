// Too lazy to fix plausible types. They don't matter here.
void operator new
();
void operator delete
();
void operator new[]
();
void operator delete[]
();
void operator +
();
void operator -
();
void operator *
();
void operator /
();
void operator %
();
void operator ^
();
void operator &
();
void operator |
();
void operator ~
();
void operator !
();
void operator =
();
void operator <
();
void operator >
();
void operator +=
();
void operator -=
();
void operator *=
();
void operator /=
();
void operator %=
();
void operator ^=
();
void operator &=
();
void operator |=
();
void operator <<
();
void operator >>
();
void operator >>=
();
void operator <<=
();
void operator ==
();
void operator !=
();
void operator <=
();
void operator >=
();
void operator &&
();
void operator ||
();
void operator ++
();
void operator --
();
void operator ,
();
void operator ->*
();
void operator ->
();
void operator ()
();
void operator []
();

// Odd ones.  The trigraph versions ??' and ??'= are too messy and too
// esoteric to bother about.
void operator xor
();
void operator bitand
();
void operator ??!
();
void operator bitor
();
void operator ??-
();
void operator compl
();
void operator xor_eq
();
void operator and_eq
();
void operator ??!=
();
void operator or_eq
();
void operator not_eq
();
void operator ??!??!
();
void operator <::>
();
void operator ??(??)
();
