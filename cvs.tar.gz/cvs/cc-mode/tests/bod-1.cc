int bar(AAAAAAAAA aaaaaaaaa,
	BBBBBBBBB bbbbbbbbb) {
    return 0;
}
