int foo() 
{
    return 1;
};


int bar()
{
    return 2;
};


int baz () {
    return 3;
};


int boz () {
    return 4;
};


int zap () 
{
    return 5;
};
