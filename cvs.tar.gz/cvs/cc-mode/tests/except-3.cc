main() 
{
    while(++i < j)
        {
            try
                {
