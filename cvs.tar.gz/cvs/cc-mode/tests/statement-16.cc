int foo()
{
    int a; if (a)
	       printf ("hmm\n");
    int b; b =
	       printf ("hmm\n");
  x:
  foo: if (a)
	printf ("hmm\n");
  bar: b=
	printf ("hmm\n");
}
