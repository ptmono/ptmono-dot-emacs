/* defined (y) */
#if foo
