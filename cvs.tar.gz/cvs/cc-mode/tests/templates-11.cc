template <Foo x, Foo y> void p();
