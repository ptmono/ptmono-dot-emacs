void main(struct test *one)
{
    for (init; test;
         cont)
        ;
    for (init;
         test;
         cont)
        ;
    for (
        init;
        test;
        cont
        )
        ;
}
