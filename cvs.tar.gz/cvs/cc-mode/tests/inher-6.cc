class Foo<x
	  >
    : public Bar<p
		 >,
      private Gnu<y
		  >
{}
