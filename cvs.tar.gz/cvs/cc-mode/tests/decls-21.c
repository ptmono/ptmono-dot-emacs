#ifdef __STDC__
static char *regprop(char *op)
#else
static char *regprop(op)
    char *op;
#endif
{}
