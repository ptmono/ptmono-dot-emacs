<!-- -*- html -*- -->
<?php
  $title = "Changes for CC Mode 5.25";
  $menufiles = array ("links.h", "changelinks.h");
  include ("header.h");
?>

<p>Release 5.25 is primarily a bug fix release.  See also the <a
href="changes-524.php">user visible changes for 5.24</a>.

<?php include ("footer.h"); ?>
