FOO (
    if (a) x
    );
BAR (
    if (a) x
    ,
    if (a) x
    );
BAR (if (a)
	 x,
     if (a)
	 x
    );
