FOO
class Foo
{
};

BAR
int				// Invalid unterminated declaration.

GNU
template <X>
class Gnapp
{
};
