int foo()
{
    int i;
}

class Foo
{
public:
    Foo()
    {
        if( i ) {
            thing();
        }
    }
    int foo( int i )
    {
        if( i ) {
            thing();
        }
        if( i ) {
            thing();
        }
        if( i ) {
            thing();
        }
    }
};
