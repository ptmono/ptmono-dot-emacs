int main() {
    switch (x) {
    case 1:
	x;
    case 2: {
	y;
    }
    }
    switch (x) {
    case 2: {
	y;
    }
    }
    switch (x) {
    case 1: case 2: {
	y;
    }
    }
    switch (x) {
    case 1:
    case 2: {
	y;
    }
    }
    switch (x) {
    case
	1: case 2: {
	y;
    }
    }
}
