struct Foo {@defs (String)};
