#define FOO(x)					\
    x = 1;		/* bar */		\

// foo
int bar;
