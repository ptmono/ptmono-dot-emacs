#if defined foo || defined bar
#endif
