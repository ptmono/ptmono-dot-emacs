public interface Foo {
    public void stuff();
    public void bad() throws Exception;
    public void evenworse();
}
