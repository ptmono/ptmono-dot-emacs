#define LOCATION_IS_DYNAMIC(X) ((X)[0]=='D')
#define FOO(X) ((X)->foo)
unsigned __int64 x = (unsigned int64) y;
int z = (a) + (b);
