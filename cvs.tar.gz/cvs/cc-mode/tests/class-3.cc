// foo
class A
{
    struct B {
        int i;
    };
    struct B {
        int i;
    };
};
