void f() {
    return (cpu_time_t) -1;
}
