int foo()
{
    if (x)
      foo:
	while (a);
}
