TestClass::TestClass(int x)
    : m_hello(x)
{
}

TestClass::TestClass(int x,
		     int y)
    : m_hello(x)
{
}
