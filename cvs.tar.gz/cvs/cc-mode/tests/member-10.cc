foo::foo() :
    a(x->m()),
    b(0)
{}
