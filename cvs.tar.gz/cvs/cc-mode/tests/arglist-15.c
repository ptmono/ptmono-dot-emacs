void f() {
    foobar (xyz,
	fsfgnu (aaa, bbb + ccc
		     + ddd
	    )
	);
    foobar (xyz, fsfgnu (aaa, bbb + ccc
			      + ddd
		     )
	);
}

/* Local Variables: */
/* c-file-offsets: ((arglist-cont . c-lineup-argcont) (arglist-cont-nonempty . (c-lineup-argcont +))) */
/* End: */
