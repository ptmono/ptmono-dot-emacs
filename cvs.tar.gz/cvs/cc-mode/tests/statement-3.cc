int foo()
{
    if(1)
        if(2)
            do {
                baz();
            }
            while( !done );
    for( i=0; i<10; i++);
    while( i++ );
    int i;
    blort();
    {
        for(i=0; i<10; i++)
            for(j=i; j<10; j++)
                bar();
        jam();
    }
    if(a==0)
        do {
            baz();
        }
        while (1);
}
