somefunc (
    arg,
    anotherfunc (arg1,
                 arg2,
                 arg3
                 arg4),
    arg5,
    arg6
    );

int main() 
{
    somefunc (
        arg,
        anotherfunc (arg1,
                     arg2,
                     arg3
                     arg4),
        arg5,
        arg6
        );
}

somefunc (
    arg,
    anotherfunc (arg1,
                 arg2,
                 arg3
                 arg4
        ));
