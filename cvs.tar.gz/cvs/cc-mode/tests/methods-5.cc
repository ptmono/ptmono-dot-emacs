class MyClass {
public:
    MyClass() {
	myVariable = 1;
    }
}
