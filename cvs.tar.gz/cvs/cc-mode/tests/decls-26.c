mytype hashmem(const unsigned char *a_) {}
