int foo()
{
    blat();
    spam();
    
    if(1)
        if(2)
            if(3)
                {
                    pingk;
                    pang;
                }
            else if (4)
                jice();
            
    blam();
        
    if(1)
        if(2)
            if(3)
                {
                    pingk;
                    pang;
                }
            else
                jice();
            
    blam();
        
    blort();
    {
        for(i=0; i<10; i++)
            for(j=i; j<10; j++)
                bar();
        jam();
    }
    if(a==0)
        do {
            baz();
        }
        while (1);
}
