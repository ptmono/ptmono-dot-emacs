INLINE
Foo::Foo (void *b)
{
  this->buf = (char *) b;
}

INLINE Foo::~Foo () {}
