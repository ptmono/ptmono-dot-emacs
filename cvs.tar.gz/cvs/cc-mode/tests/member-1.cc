TestClass::TestClass(int x) throw(Something)
    : m_hello(x)
{
}

TestClass::TestClass(int x,
		     int y) throw(Something)
    : m_hello(x)
{
}
