pair<int> uwbits[] = {
    {1,    1},
    {0,    0},
};
