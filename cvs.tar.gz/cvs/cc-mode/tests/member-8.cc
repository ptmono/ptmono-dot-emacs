hej::hej(int h, float f, double d)
    : m_h(h),
      m_f(f)
    , m_d(d)
{}
hej::hej(int h, float f, double d)
    : m_h(h)
    , m_f(f)
    , m_d(d)
{}
