int main() 
{
    enum jimmy j;
    {
        enum john {
            a,
            b,
            c
        }
    }
}

enum jub {
    a,
    b,
    c
