main()
{
    int a;

    do {
        int i;
    } while (1);

    switch (a) {
    case 1:
        do {
            int i;
        } while (1);
    }
}
