#define check_refs(S) Pike_fatal(msg_sval_obj_wo_refs);
PMOD_EXPORT extern const char msg_ssval_obj_wo_refs[];
