void foo() {
    if ( abc
       && ( bits0
	  & bits1)
       && !jkl
       ) {}
}

/* Local Variables: */
/* c-file-offsets: ((arglist-cont . c-lineup-arglist-close-under-paren) (arglist-cont-nonempty . c-lineup-arglist-close-under-paren) (arglist-close . c-lineup-arglist-close-under-paren)) */
/* End: */
