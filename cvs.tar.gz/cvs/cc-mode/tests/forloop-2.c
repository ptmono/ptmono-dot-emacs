int main()
{
    for (a (
	     x,
	     y
	     );
	 b (x,
	    y,
	    z
	     );
	 c)
	;
}
