long_function_name (a,
		    b
		   );
long_function_name (
    a,
    b
);
long_function_name ({
	a;
    },
    b
    );
long_function_name (
    {
	a;
    },
    b
);
long_function_name (a,
		    {
			b;
		    }
		   );
long_function_name (
    a,
    {
	b;
    }
);
long_function_name ({
	a;
    },
    {
	b;
    }
    );
long_function_name (
    {
	a;
    },
    {
	b;
    }
);

/* Local Variables: */
/* c-file-offsets: ((arglist-close . c-lineup-close-paren)) */
/* End: */

