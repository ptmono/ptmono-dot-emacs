extern void bar(void);
#define foo() bar()
struct
x {}; /* Not knr-argdecl */
