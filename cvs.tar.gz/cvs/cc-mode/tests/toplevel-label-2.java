case '<': emit("iinc p -1");
case '>':
