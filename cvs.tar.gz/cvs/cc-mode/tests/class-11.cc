class foo
{};


class derived : public base1,
                public base 2 {
    x;
    y;
}
