int
main()
{
    if (s->bbox.left < s->bbox.right - width)
	rectangle[i++] = NSMakeRect(s->bbox.right - width,
				    s->bbox.top + height,
				    width,
				    fuoo(s->bbox.bottom
                                         + 100));
}
