static PyObject **
unpack_sequence(v, argcnt, why)
PyObject **v;
int argcnt;
enum *why_code;
{
    int i;
}

static PyObject **
unpack_sequence(v, argcnt, why) PyObject **v;
				int argcnt;
				enum *why_code;
{
    int i;
}

/* Local Variables: */
/* c-file-offsets: ((knr-argdecl-intro . 0)) */
/* End: */
