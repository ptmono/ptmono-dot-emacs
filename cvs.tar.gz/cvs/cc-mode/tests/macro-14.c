#define (foo) \
  #foo
