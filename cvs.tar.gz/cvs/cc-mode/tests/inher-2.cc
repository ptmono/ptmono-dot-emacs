class A:

    public B
