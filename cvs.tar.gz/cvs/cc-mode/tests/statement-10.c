void foo()
{
    static struct Pattern nums
        = {1, 2, 3};

    int j = 2;
}
