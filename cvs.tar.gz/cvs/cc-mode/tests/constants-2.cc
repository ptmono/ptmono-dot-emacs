bool f() {
    my_true = true;
    false_val = false;
    if (x == false) return false;
    return true;
}
