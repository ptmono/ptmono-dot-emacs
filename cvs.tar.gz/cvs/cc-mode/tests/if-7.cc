int foo()
{
    if (a)
	do
	    if (x) y();
	while (0);
    else b;
}
