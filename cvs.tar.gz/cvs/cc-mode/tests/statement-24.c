void f() {
    if (x) n =
	       17;
    else while (a)
	     b;
    if (x) n =
	       17;
    else n =
	     17;
    if (x) if (y) n =
		      17;
	else n =
		 17;
    else n =
	     17;
}
