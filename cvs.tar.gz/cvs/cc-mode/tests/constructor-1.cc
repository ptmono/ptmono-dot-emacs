class ACE_PSOS_Time_t
{
    ACE_PSOS_Time_t (void);
    ACE_PSOS_Time_t (const timespec_t& t);
    ~ACE_PSOS_Time_t();
}
