public class Test
    implements Cloneable,
	       Runnable
{
    public void blah()
	throws ArrayIndexOutOfBoundsException, ClassNotFoundException,
	       IllegalAccessException, NullPointerException
    {
    }

    public void run()
    {
    }
}

public class Test implements Cloneable,
                             Runnable
{}
