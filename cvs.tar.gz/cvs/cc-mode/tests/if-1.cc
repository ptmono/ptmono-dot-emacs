void dummy()
{
    if (a)
        {
        }
    else if (b)
        {
        }
    else if (c)
        {
        }
    else if (d)
        {
        }
    else
        {
        }
}
