void
f(void)
{ 
    { b;
	c;
	d;
    }
}
