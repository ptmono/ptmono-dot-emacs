struct Foo : Bar,
             Baz
{};
