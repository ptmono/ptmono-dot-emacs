@interface Foo
(Bar)
<X, Y, Z>
@end

@interface Foo (Bar)
<X, Y, Z>
@end
