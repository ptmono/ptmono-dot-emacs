int foo () {
#define SOMETHING
 foo:;
}
/* Local Variables: */
/* c-file-style: "gnu" */
/* End: */
