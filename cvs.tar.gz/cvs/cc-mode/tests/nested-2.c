double
hypotenuse (double a, double b)
{
    double square (double x)
    {
	return x * x;
    }

    return sqrt (square (a) + square (b));
}
