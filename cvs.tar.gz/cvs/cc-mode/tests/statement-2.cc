void someFunction()
{
    switch (result) {
    case 3:
    {
        int someVar;
        doThis(someVar);
        break;
    } // end case 1
    case 1: {
        int someVar;
        doThis(someVar);
        break;
    } // end case 1
    case 2:
        doThis();
        doThat();
        break;
    case 2:
        doThis();
        doThat();
        break;
    } // end switch result
} // end someFunction
