void spam()
{
    if (4)
        if (3)
            
            {
            }
    foo;
}
