int main()
{
    bar();
  label:
    plop();
    if (func(arg1, arg2)) {
      error:
        dothis();
    }
  foo: {
      bar: if (t)
            x;
        y;
    }
    y;
    {
      bar: if (t)
            x;
    }
}

/* Local Variables: */
/* font-lock-maximum-decoration: 2 */
/* End: */

