int a = foo (
    1);
#define X(A, B)					\
    do {					\
	printf (A, B);				\
    } while (0)

int a = foo (
    1);
#define X(A, B) do {				\
	printf (A, B);				\
    } while (0)

int dribble() {
    if (!running)
	error(\"Not running!\");
#define X(A, B)					\
    do {					\
	printf (A, B);				\
    } while (0)
}

int dribble() {
    if (!running)
	error(\"Not running!\");
#define X(A, B) do {				\
	printf (A, B);				\
    } while (0)
}
