int main() {
    catch(func());
    // Not valid C++, but it still shouldn't infloop on this line.
}
