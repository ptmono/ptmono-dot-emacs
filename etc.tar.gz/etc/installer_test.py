#!/usr/bin/python
# -*- coding:utf-8 -*-

from installer import *

if __name__ == "__main__":
    test()
