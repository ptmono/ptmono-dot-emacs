void foo()
    throw (int);

struct C
{
    void foo()
        throw (int);
};
