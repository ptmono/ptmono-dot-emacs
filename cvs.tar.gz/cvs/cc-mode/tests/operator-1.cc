operator MICO_LongDouble () const;
operator MICO_LongLong () const {}
